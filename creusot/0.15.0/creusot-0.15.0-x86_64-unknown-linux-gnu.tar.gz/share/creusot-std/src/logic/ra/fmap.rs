#[cfg(creusot)]
use crate::logic::any;
use crate::{
    logic::{
        FMap,
        ra::{RA, UnitRA, update::LocalUpdate},
    },
    prelude::*,
};

impl<K, V: RA> RA for FMap<K, V> {
    #[logic(open)]
    fn op(self, other: Self) -> Option<Self> {
        pearlite! {
            if (forall<k: K> self.lookup(k).op(other.lookup(k)) != None) {
                Some(self.total_op(other))
            } else {
                None
            }
        }
    }

    #[logic(open)]
    #[ensures(result == (exists<factor> self.op(factor) == Some(other)))]
    fn incl(self, other: Self) -> bool {
        pearlite! {
            let r = forall<k: K> self.lookup(k).incl(other.lookup(k));

            proof_assert!(r ==> {
                let factor = other.filter_map(|(k, vo): (K, V)|
                    if self.lookup(k).incl(Some(vo)) {
                        Some(vo).factor(self.lookup(k))
                    } else { None }
                );

                match self.op(factor) {
                    None => false,
                    Some(o) => o.ext_eq(other)
                }
            });

            r
        }
    }

    #[logic(open, inline)]
    #[ensures(#[trigger(self == other)] result == (self == other))]
    fn eq(self, other: Self) -> bool {
        pearlite! {
            let _ = Self::ext_eq;
            forall<k: K> self.lookup(k).eq(other.lookup(k))
        }
    }

    #[logic(law)]
    #[ensures(a.op(b) == b.op(a))]
    fn commutative(a: Self, b: Self) {
        proof_assert!(match (a.op(b), b.op(a)) {
            (Some(ab), Some(ba)) => ab.ext_eq(ba),
            (None, None) => true,
            _ => false,
        })
    }

    #[logic]
    #[ensures(a.op(b).and_then_logic(|ab: Self| ab.op(c)) == b.op(c).and_then_logic(|bc| a.op(bc)))]
    fn associative(a: Self, b: Self, c: Self) {
        match (a.op(b), b.op(c)) {
            (Some(ab), Some(bc)) => match (ab.op(c), a.op(bc)) {
                (Some(x), Some(y)) => proof_assert!(x.ext_eq(y)),
                _ => (),
            },
            _ => (),
        }
    }

    #[logic(open)]
    fn core(self) -> Option<Self> {
        Some(self.filter_map(|(_, v): (K, V)| v.core()))
    }

    #[logic]
    #[requires(self.core() != None)]
    #[ensures({
        let c = self.core().unwrap_logic();
        c.op(c) == Some(c)
    })]
    #[ensures(self.core().unwrap_logic().op(self) == Some(self))]
    fn core_idemp(self) {
        self.core_total_idemp()
    }

    #[logic]
    #[requires(i.op(i) == Some(i))]
    #[requires(i.op(self) == Some(self))]
    #[ensures(match self.core() {
        Some(c) => i.incl(c),
        None => false,
    })]
    fn core_is_maximal_idemp(self, i: Self) {
        let _ = V::core_is_maximal_idemp;
    }

    #[logic(open)]
    #[ensures(result == (forall<x, y> self.op(x) != None ==>
        self.op(x) == self.op(y) ==> x == y))]
    fn cancelable(self) -> bool {
        proof_assert!(
            (forall<x, y> self.op(x) != None ==> self.op(x) == self.op(y) ==> x == y) ==>
            forall<k> match self.lookup(k) {
                None => true,
                Some(v) => forall<x, y> Some(v).op(x) != None ==> Some(v).op(x) == Some(v).op(y) ==> {
                    let fx = match x {
                        None => FMap::empty(),
                        Some(x) => FMap::singleton(k, x),
                    };
                    let fy = match y {
                        None => FMap::empty(),
                        Some(y) => FMap::singleton(k, y),
                    };
                    let opx = self.op(fx).unwrap_logic();
                    let opy = self.op(fy).unwrap_logic();
                    opx.ext_eq(opy) && (opx == opy ==> fx == fy)
                }
            }
        );
        proof_assert!((forall<k> self.lookup(k).cancelable()) ==>
            forall<x, y> self.op(x) != None ==> self.op(x) == self.op(y) ==>
            x.ext_eq(y)
        );
        pearlite! { forall<k> self.lookup(k).cancelable() }
    }
}

impl<K, V: RA> UnitRA for FMap<K, V> {
    #[logic(open)]
    #[ensures(forall<x: Self> #[trigger(x.op(result))] x.op(result) == Some(x))]
    fn unit() -> Self {
        proof_assert!(forall<x: Self> x.op(Self::empty()).unwrap_logic().ext_eq(x));
        Self::empty()
    }

    #[logic(open)]
    #[ensures(self.core() == Some(result))]
    fn core_total(self) -> Self {
        self.filter_map(|(_, v): (K, V)| v.core())
    }

    #[logic]
    #[ensures(self.core_total().op(self.core_total()) == Some(self.core_total()))]
    #[ensures(self.core_total().op(self) == Some(self))]
    fn core_total_idemp(self) {
        let _ = V::core_idemp;
        let c = self.core_total();
        proof_assert!(c.op(c).unwrap_logic().ext_eq(c));
        proof_assert!(c.op(self).unwrap_logic().ext_eq(self));
    }
}

impl<K, V: RA> FMap<K, V> {
    #[logic]
    #[requires(forall<k: K> self.lookup(k).op(other.lookup(k)) != None)]
    #[ensures(forall<k: K> Some(result.lookup(k)) == self.lookup(k).op(other.lookup(k)))]
    pub fn total_op(self, other: Self) -> Self {
        self.merge(other, |(x, y): (V, V)| match x.op(y) {
            Some(r) => r,
            _ => any(),
        })
    }
}

/// Add a key-value to an authority/fragment pair of [`FMap`]s.
///
/// It requires that the key is not in the map yet.
pub struct FMapInsertLocalUpdate<K, V>(pub Snapshot<K>, pub Snapshot<V>);

impl<K, V: RA> LocalUpdate<FMap<K, V>> for FMapInsertLocalUpdate<K, V> {
    #[logic(open, inline)]
    fn premise(self, from_auth: FMap<K, V>, _: FMap<K, V>) -> bool {
        from_auth.lookup(*self.0) == None
    }

    #[logic(open, inline)]
    fn update(self, from_auth: FMap<K, V>, from_frag: FMap<K, V>) -> (FMap<K, V>, FMap<K, V>) {
        (from_auth.add(*self.0, *self.1), from_frag.add(*self.0, *self.1))
    }

    #[logic]
    #[allow(unused)]
    #[requires(self.premise(from_auth, from_frag))]
    #[requires(Some(from_frag).op(frame) == Some(Some(from_auth)))]
    #[ensures({
        let (to_auth, to_frag) = self.update(from_auth, from_frag);
        Some(to_frag).op(frame) == Some(Some(to_auth))
    })]
    fn frame_preserving(
        self,
        from_auth: FMap<K, V>,
        from_frag: FMap<K, V>,
        frame: Option<FMap<K, V>>,
    ) {
        let (to_auth, to_frag) = self.update(from_auth, from_frag);
        proof_assert!(match Some(to_frag).op(frame) {
            Some(Some(x)) => to_auth.ext_eq(x),
            _ => false,
        });
    }
}

/// Modifies a key-value mapping in an authority/fragment pair of [`FMap`]s.
///
/// It requires that the key is in the fragment.
pub struct FMapKeyLocalUpdate<K, U>(pub Snapshot<K>, pub U);

impl<K, V: RA, U: LocalUpdate<V>> LocalUpdate<FMap<K, V>> for FMapKeyLocalUpdate<K, U> {
    #[logic(open, inline)]
    fn premise(self, from_auth: FMap<K, V>, from_frag: FMap<K, V>) -> bool {
        pearlite! {
            match (from_auth.lookup(*self.0), from_frag.lookup(*self.0)) {
                (Some(auth_v), Some(frag_v)) => self.1.premise(auth_v, frag_v),
                (_, None) => false,
                _ => true,
            }
        }
    }

    #[logic(open, inline)]
    fn update(self, from_auth: FMap<K, V>, from_frag: FMap<K, V>) -> (FMap<K, V>, FMap<K, V>) {
        let (auth, frag) = self.1.update(from_auth[*self.0], from_frag[*self.0]);
        (from_auth.add(*self.0, auth), from_frag.add(*self.0, frag))
    }

    #[logic]
    #[allow(unused)]
    #[requires(self.premise(from_auth, from_frag))]
    #[requires(Some(from_frag).op(frame) == Some(Some(from_auth)))]
    #[ensures({
        let (to_auth, to_frag) = self.update(from_auth, from_frag);
        Some(to_frag).op(frame) == Some(Some(to_auth))
    })]
    fn frame_preserving(
        self,
        from_auth: FMap<K, V>,
        from_frag: FMap<K, V>,
        frame: Option<FMap<K, V>>,
    ) {
        match (from_auth.lookup(*self.0), from_frag.lookup(*self.0)) {
            (Some(auth_v), Some(frag_v)) => {
                let frame_k = match frame {
                    Some(frame) => frame.lookup(*self.0),
                    None => None,
                };
                self.1.frame_preserving(auth_v, frag_v, frame_k);

                let (to_auth, to_frag) = self.update(from_auth, from_frag);
                proof_assert!(match Some(to_frag).op(frame) {
                    Some(Some(x)) => to_auth.ext_eq(x),
                    _ => false,
                });
            }
            _ => (),
        }
    }
}
