#[cfg(creusot)]
use crate::resolve::structural_resolve;
use crate::{
    ghost::Plain,
    logic::{Mapping, ops::IndexLogic},
    prelude::*,
    std::ops::RangeInclusiveExt as _,
};
use core::{
    marker::PhantomData,
    ops::{Range, RangeFrom, RangeFull, RangeInclusive, RangeTo, RangeToInclusive},
};

/// A type of sequence usable in pearlite and `ghost!` blocks.
///
/// # Logic
///
/// This type is (in particular) the logical representation of a [`Vec`]. This can be
/// accessed via its [view][crate::model::View] (The `@` operator).
///
/// ```rust,creusot
/// # use creusot_std::prelude::*;
/// #[logic]
/// fn get_model<T>(v: Vec<T>) -> Seq<T> {
///     pearlite!(v@)
/// }
/// ```
///
/// # Ghost
///
/// Since [`Vec`] have finite capacity, this could cause some issues in ghost code:
/// ```rust,creusot,compile_fail
/// ghost! {
///     let mut v = Vec::new();
///     for _ in 0..=usize::MAX as u128 + 1 {
///         v.push(0); // cannot fail, since we are in a ghost block
///     }
///     proof_assert!(v@.len() <= usize::MAX@); // by definition
///     proof_assert!(v@.len() > usize::MAX@); // uh-oh
/// }
/// ```
///
/// This type is designed for this use-case, with no restriction on the capacity.
#[builtin("seq.Seq.seq")]
pub struct Seq<T>(PhantomData<T>);

/// Logical definitions
impl<T> Seq<T> {
    /// Returns the empty sequence.
    #[logic]
    #[builtin("seq.Seq.empty", ascription)]
    pub fn empty() -> Self {
        dead
    }

    /// Create a new sequence in pearlite.
    ///
    /// The new sequence will be of length `n`, and will contain `mapping[i]` at index `i`.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(Seq::create(5, |i| i + 1));
    /// proof_assert!(s.len() == 5);
    /// proof_assert!(forall<i> 0 <= i && i < 5 ==> s[i] == i + 1);
    /// ```
    #[logic]
    #[builtin("seq.Seq.create")]
    pub fn create(n: Int, mapping: Mapping<Int, T>) -> Self {
        let _ = n;
        let _ = mapping;
        dead
    }

    /// Returns the value at index `ix`.
    ///
    /// If `ix` is out of bounds, return `None`.
    #[logic(open)]
    pub fn get_logic(self, ix: Int) -> Option<T> {
        if 0 <= ix && ix < self.len() { Some(self.index_logic(ix)) } else { None }
    }

    /// Returns the value at index `ix`.
    ///
    /// If `ix` is out of bounds, the returned value is meaningless.
    ///
    /// You should prefer using the indexing operator `s[ix]`.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(Seq::singleton(2));
    /// proof_assert!(s.index_logic_unsized(0) == 2);
    /// proof_assert!(s[0] == 2); // prefer this
    /// ```
    #[logic]
    #[builtin("seq.Seq.get")]
    pub fn index_logic_unsized<'a>(self, ix: Int) -> &'a T {
        let _ = ix;
        dead
    }

    /// Returns the subsequence between indices `start` and `end`.
    ///
    /// If either `start` or `end` are out of bounds, the result is meaningless.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let subs = snapshot! {
    ///     let s: Seq<Int> = Seq::create(10, |i| i);
    ///     s.subsequence(2, 5)
    /// };
    /// proof_assert!(subs.len() == 3);
    /// proof_assert!(subs[0] == 2 && subs[1] == 3 && subs[2] == 4);
    /// ```
    #[logic]
    #[builtin("seq.Seq.([..])")]
    pub fn subsequence(self, start: Int, end: Int) -> Self {
        let _ = start;
        let _ = end;
        dead
    }

    /// Create a sequence containing one element.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(Seq::singleton(42));
    /// proof_assert!(s.len() == 1);
    /// proof_assert!(s[0] == 42);
    /// ```
    #[logic]
    #[builtin("seq.Seq.singleton")]
    pub fn singleton(value: T) -> Self {
        let _ = value;
        dead
    }

    /// Returns the sequence without its first element.
    ///
    /// If the sequence is empty, the result is meaningless.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(seq![5, 10, 15]);
    /// proof_assert!(s.tail() == seq![10, 15]);
    /// proof_assert!(s.tail().tail() == Seq::singleton(15));
    /// proof_assert!(s.tail().tail().tail() == Seq::empty());
    /// ```
    #[logic(open, inline)]
    pub fn tail(self) -> Self {
        self[1..]
    }

    /// Returns the sequence without its last element.
    ///
    /// If the sequence is empty, the result is meaningless.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(seq![5, 10, 15]);
    /// proof_assert!(s.init() == seq![5, 10]);
    /// proof_assert!(s.init().init() == Seq::singleton(5));
    /// proof_assert!(s.init().init().init() == Seq::empty());
    /// ```
    #[logic(open, inline)]
    pub fn init(self) -> Self {
        self[..self.len() - 1]
    }

    /// Returns the number of elements in the sequence, also referred to as its 'length'.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// #[requires(v@.len() > 0)]
    /// fn f<T>(v: Vec<T>) { /* ... */ }
    /// ```
    #[logic]
    #[builtin("seq.Seq.length")]
    pub fn len_logic(self) -> Int {
        dead
    }

    /// Returns a new sequence, where the element at index `ix` has been replaced by `x`.
    ///
    /// If `ix` is out of bounds, the result is meaningless.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(Seq::create(2, |_| 0));
    /// let s2 = snapshot!(s.set(1, 3));
    /// proof_assert!(s2[0] == 0);
    /// proof_assert!(s2[1] == 3);
    /// ```
    #[logic]
    #[builtin("seq.Seq.set")]
    pub fn set(self, ix: Int, x: T) -> Self {
        let _ = ix;
        let _ = x;
        dead
    }

    /// Extensional equality
    ///
    /// Returns `true` if `self` and `other` have the same length, and contain the same
    /// elements at the same indices.
    ///
    /// This is in fact equivalent with normal equality.
    #[logic]
    #[builtin("seq.Seq.(==)")]
    pub fn ext_eq(self, other: Self) -> bool {
        let _ = other;
        dead
    }

    // internal wrapper to match the order of arguments of Seq.cons
    #[doc(hidden)]
    #[logic]
    #[builtin("seq.Seq.cons")]
    pub fn cons_(_: T, _: Self) -> Self {
        dead
    }

    /// Returns a new sequence, where `x` has been prepended to `self`.
    ///
    /// # Example
    ///
    /// ```
    /// let s = snapshot!(Seq::singleton(1));
    /// let s2 = snapshot!(s.cons(2));
    /// proof_assert!(s2[0] == 2);
    /// proof_assert!(s2[1] == 1);
    /// ```
    #[logic(open, inline)]
    pub fn cons(self, x: T) -> Self {
        Self::cons_(x, self)
    }

    /// Returns a new sequence, where `x` has been appended to `self`.
    ///
    /// # Example
    ///
    /// ```
    /// let s = snapshot!(Seq::singleton(1));
    /// let s2 = snapshot!(s.snoc(2));
    /// proof_assert!(s2[0] == 1);
    /// proof_assert!(s2[1] == 2);
    /// ```
    #[logic]
    #[builtin("seq.Seq.snoc")]
    pub fn snoc(self, x: T) -> Self {
        let _ = x;
        dead
    }

    /// Returns a new sequence, made of the concatenation of `self` and `other`.
    ///
    /// See also the program function [`Seq::extend`].
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s1 = snapshot!(Seq::singleton(1));
    /// let s2 = snapshot!(Seq::create(2, |i| i));
    /// let s = snapshot!(s1.concat(s2));
    /// proof_assert!(s[0] == 1);
    /// proof_assert!(s[1] == 0);
    /// proof_assert!(s[2] == 1);
    /// ```
    #[logic]
    #[builtin("seq.Seq.(++)")]
    pub fn concat(self, other: Self) -> Self {
        let _ = other;
        dead
    }

    #[logic]
    #[ensures(result.len() == self.len())]
    #[ensures(forall<i> 0 <= i && i < self.len() ==> result[i] == m[self[i]])]
    #[variant(self.len())]
    pub fn map<U>(self, m: Mapping<T, U>) -> Seq<U> {
        if self.len() == 0 {
            Seq::empty()
        } else {
            self.tail().map(m).cons(m.get(*self.index_logic_unsized(0)))
        }
    }

    #[logic(open, inline)]
    pub fn flat_map<U>(self, f: Mapping<T, Seq<U>>) -> Seq<U> {
        self.map(f).flatten()
    }

    /// Returns a new sequence, which is `self` in reverse order.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(Seq::create(3, |i| i));
    /// let s2 = snapshot!(s.reverse());
    /// proof_assert!(s2[0] == 2);
    /// proof_assert!(s2[1] == 1);
    /// proof_assert!(s2[2] == 0);
    /// ```
    #[logic]
    #[builtin("seq.Reverse.reverse")]
    pub fn reverse(self) -> Self {
        dead
    }

    #[logic]
    #[ensures(Self::empty().reverse() == Self::empty())]
    pub fn reverse_empty() {}

    #[logic]
    #[requires(0 <= position && position <= self.len())]
    #[ensures(result.len() == self.len() + 1)]
    #[ensures(forall<i> 0 <= i && i <= self.len() ==>
        if i < position {
            result[i] == self[i]
        } else if i == position {
            result[i] == value
        } else {
            result[i] == self[i - 1]
        }
    )]
    #[variant(position)]
    pub fn add_at(self, position: Int, value: T) -> Self {
        if position == 0 {
            self.cons(value)
        } else {
            self.tail().add_at(position - 1, value).cons(self[0])
        }
    }

    /// Returns a new sequence, which is `self` with the element at the given `index` removed.
    ///
    /// See also the program function [`Seq::remove`].
    ///
    /// # Example
    ///
    /// ```rust,creusot
    /// # use creusot_std::prelude::*;
    /// let s = snapshot!(seq![7, 8, 9]);
    /// proof_assert!(removed(*s, 1) == seq![7, 9]);
    /// ```
    #[logic(open)]
    pub fn removed(self, index: Int) -> Self {
        pearlite! { self[..index].concat(self[index+1..]) }
    }

    /// Returns `true` if `other` is a permutation of `self`.
    #[logic(open)]
    pub fn permutation_of(self, other: Self) -> bool {
        self.permut(other, 0, self.len())
    }

    /// Returns `true` if:
    /// - `self` and `other` have the same length
    /// - `start` and `end` are in bounds (between `0` and `self.len()` included)
    /// - Every element occurs as many times in `self[start..end]` as in `other[start..end]`.
    #[logic]
    #[builtin("seq.Permut.permut")]
    pub fn permut(self, other: Self, start: Int, end: Int) -> bool {
        let _ = other;
        let _ = start;
        let _ = end;
        dead
    }

    /// Returns `true` if:
    /// - `self` and `other` have the same length
    /// - `i` and `j` are in bounds (between `0` and `self.len()` excluded)
    /// - `other` is equal to `self` where the elements at `i` and `j` are swapped
    #[logic]
    #[builtin("seq.Permut.exchange")]
    pub fn exchange(self, other: Self, i: Int, j: Int) -> bool {
        let _ = other;
        let _ = i;
        let _ = j;
        dead
    }

    /// Returns `true` if there is an index `i` such that `self[i] == x`.
    #[logic(open)]
    pub fn contains(self, x: T) -> bool {
        pearlite! { exists<i> 0 <= i &&  i < self.len() && self[i] == x }
    }

    /// Returns `true` if `self` is sorted between `start` and `end`.
    #[logic(open)]
    pub fn sorted_range(self, start: Int, end: Int) -> bool
    where
        T: OrdLogic,
    {
        pearlite! {
            forall<i, j> start <= i && i <= j && j < end ==> self[i] <= self[j]
        }
    }

    /// Returns `true` if `self` is sorted.
    #[logic(open)]
    pub fn sorted(self) -> bool
    where
        T: OrdLogic,
    {
        self.sorted_range(0, self.len())
    }

    #[logic]
    #[ensures(self.concat(other).contains(x) == self.contains(x) || other.contains(x))]
    pub fn concat_contains(self, other: Self, x: T) {}

    #[logic]
    #[ensures(self.concat(other1).concat(other2) == self.concat(other1.concat(other2)))]
    pub fn concat_assoc(self, other1: Self, other2: Self) {}

    #[logic]
    #[ensures(self.concat(Seq::empty()) == self)]
    #[ensures(Seq::empty().concat(self) == self)]
    pub fn concat_empty(self) {}

    #[logic]
    #[ensures(self.concat(other).reverse() == other.reverse().concat(self.reverse()))]
    pub fn reverse_concat(self, other: Self) {}

    #[logic]
    #[ensures(Seq::singleton(x).map(f) == Seq::singleton(f.get(x)))]
    pub fn singleton_map<U>(x: T, f: Mapping<T, U>) {
        let _ = Self::ext_eq;
    }

    #[logic]
    #[ensures(self.snoc(x).map(f) == self.map(f).snoc(f.get(x)))]
    pub fn snoc_map<U>(self, x: T, f: Mapping<T, U>) {}

    #[logic]
    #[ensures(self.cons(x).map(f) == self.map(f).cons(f.get(x)))]
    pub fn cons_map<U>(self, x: T, f: Mapping<T, U>) {}

    #[logic]
    #[ensures(self.concat(other).map(f) == self.map(f).concat(other.map(f)))]
    pub fn concat_map<U>(self, other: Self, f: Mapping<T, U>) {}

    #[logic]
    #[ensures(Seq::singleton(x).flat_map(f) == f.get(x))]
    pub fn singleton_flat_map<U>(x: T, f: Mapping<T, Seq<U>>) {}

    #[logic]
    #[ensures(self.snoc(x).flat_map(f) == self.flat_map(f).concat(f.get(x)))]
    pub fn snoc_flat_map<U>(self, x: T, f: Mapping<T, Seq<U>>) {
        let _ = Seq::<Seq<U>>::snoc_flatten;
        let _ = Self::snoc_map::<Seq<U>>;
    }

    #[logic]
    #[ensures(self.cons(x).flat_map(f) == f.get(x).concat(self.flat_map(f)))]
    pub fn cons_flat_map<U>(self, x: T, f: Mapping<T, Seq<U>>) {
        let _ = Seq::<Seq<U>>::cons_flatten;
        let _ = Self::cons_map::<Seq<U>>;
    }

    #[logic]
    #[ensures(self.concat(other).flat_map(f) == self.flat_map(f).concat(other.flat_map(f)))]
    pub fn concat_flat_map<U>(self, other: Seq<T>, f: Mapping<T, Seq<U>>) {
        let _ = Seq::<Seq<U>>::concat_flatten;
        let _ = Self::concat_map::<Seq<U>>;
    }
}

impl<T> Seq<Seq<T>> {
    #[logic(open)]
    #[variant(self.len())]
    pub fn flatten(self) -> Seq<T> {
        if self.len() == 0 {
            Seq::empty()
        } else {
            self.index_logic_unsized(0).concat(self.tail().flatten())
        }
    }

    #[logic]
    #[ensures(Seq::singleton(x).flatten() == x)]
    pub fn singleton_flatten(x: Seq<T>) {}

    #[logic]
    #[ensures(self.snoc(x).flatten() == self.flatten().concat(x))]
    pub fn snoc_flatten(self, x: Seq<T>) {
        proof_assert!(self.snoc(x) == self.concat(Seq::singleton(x)));
        self.concat_flatten(Seq::singleton(x));
        Self::singleton_flatten(x);
    }

    #[logic]
    #[ensures(self.cons(x).flatten() == x.concat(self.flatten()))]
    pub fn cons_flatten(self, x: Seq<T>) {}

    #[logic]
    #[ensures(self.concat(other).flatten() == self.flatten().concat(other.flatten()))]
    #[variant(self.len())]
    pub fn concat_flatten(self, other: Self) {
        if self.len() > 0 {
            self.tail().concat_flatten(other);
        }
    }

    #[logic]
    #[ensures(self.flatten() == self.flat_map(|s|s))]
    pub fn flatten_flat_map(self) {}
}

impl<T> Seq<&T> {
    /// Convert `Seq<&T>` to `Seq<T>`.
    ///
    /// This is simply a utility method, because `&T` is equivalent to `T` in pearlite.
    #[logic]
    #[builtin("identity")]
    pub fn to_owned_seq(self) -> Seq<T> {
        dead
    }
}

impl<T> IndexLogic<Int> for Seq<T> {
    type Item = T;

    #[logic]
    #[builtin("seq.Seq.get")]
    fn index_logic(self, _: Int) -> Self::Item {
        dead
    }
}

impl<T> IndexLogic<Range<Int>> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, range: Range<Int>) -> Self::Item {
        self.subsequence(range.start, range.end)
    }
}

impl<T> IndexLogic<RangeInclusive<Int>> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, range: RangeInclusive<Int>) -> Self::Item {
        self.subsequence(range.start_log(), range.end_log() + 1)
    }
}

impl<T> IndexLogic<RangeFull> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, _: RangeFull) -> Self::Item {
        self
    }
}

impl<T> IndexLogic<RangeFrom<Int>> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, range: RangeFrom<Int>) -> Self::Item {
        self.subsequence(range.start, self.len())
    }
}

impl<T> IndexLogic<RangeTo<Int>> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, range: RangeTo<Int>) -> Self::Item {
        self.subsequence(0, range.end)
    }
}

impl<T> IndexLogic<RangeToInclusive<Int>> for Seq<T> {
    type Item = Seq<T>;

    #[logic(open, inline)]
    fn index_logic(self, range: RangeToInclusive<Int>) -> Self::Item {
        self.subsequence(0, range.end + 1)
    }
}

impl<T: PartialOrdLogic> PartialOrdLogic for Seq<T> {
    #[logic(open)]
    fn lt_log(self, other: Self) -> bool {
        pearlite! {
            (exists<i: Int> 0 <= i && i < self.len() && i < other.len() &&
                (forall<j: Int> 0 <= j && j < i ==> self[j] == other[j]) &&
                self[i] < other[i])
            ||
            self.len() < other.len() &&
            (forall<i: Int> 0 <= i && i < self.len() ==> self[i] == other[i])
        }
    }

    #[logic(law)]
    #[ensures(!(self < self))]
    fn irreflexive(self) {}

    #[logic(law)]
    #[requires(x < y)]
    #[requires(y < z)]
    #[ensures(x < z)]
    fn transitive(x: Self, y: Self, z: Self) {}

    #[logic(law)]
    #[ensures((self <= other) == (self < other || self == other))]
    fn le_lt_log(self, other: Self) {}
}

impl<T: OrdLogic> Seq<T> {
    #[logic]
    #[requires(self.len() > 0 && other.len() > 0)]
    #[requires(self[0] == other[0])]
    #[ensures((self < other) == (self[1..] < other[1..]))]
    fn lt_log_tail(self, other: Self) {
        pearlite! {
            let _ = |i| {
                if 0 <= i && i < self.len() && i < other.len() &&
                        (forall<j: Int> 0 <= j && j < i ==> self[j] == other[j]) &&
                        self[i] < other[i] {
                    proof_assert!(forall<j: Int> 0 <= j && j < i-1 ==> self[1..][j] == other[1..][j]);
                    proof_assert!(self[1..][i-1] < other[1..][i-1]);
                }
            };
        }
    }
}

impl<T: OrdLogic> OrdLogic for Seq<T> {
    #[logic(law)]
    #[ensures(self < other || self == other || other < self)]
    #[variant(self.len())]
    fn lt_log_total(self, other: Self) {
        if self.len() > 0 && other.len() > 0 {
            if self[0] == other[0] {
                self[1..].lt_log_total(other[1..]);
                self.lt_log_tail(other);
                other.lt_log_tail(self);
                proof_assert!(forall<i> 0 < i && i < self.len() ==> self[i] == self[1..][i-1]);
                proof_assert!(forall<i> 0 < i && i < other.len() ==> other[i] == other[1..][i-1]);
            } else {
                self[0].lt_log_total(other[0]);
            }
        }
    }
}

/// Ghost definitions

impl<T> Invariant for Seq<T> {
    #[logic(open, prophetic, inline)]
    #[creusot::trusted_trivial_if_param_trivial]
    fn invariant(self) -> bool {
        pearlite! { forall<i> 0 <= i && i < self.len() ==> inv(self.index_logic_unsized(i)) }
    }
}

impl<T> Resolve for Seq<T> {
    #[logic(open, prophetic)]
    #[creusot::trusted_trivial_if_param_trivial]
    fn resolve(self) -> bool {
        pearlite! { forall<i : Int> 0 <= i && i < self.len() ==> resolve(self[i]) }
    }

    #[trusted]
    #[logic(prophetic)]
    #[requires(structural_resolve(self))]
    #[ensures(self.resolve())]
    fn resolve_coherence(self) {}
}

impl<T> Seq<T> {
    /// Constructs a new, empty `Seq<T>`.
    ///
    /// This can only be manipulated in the ghost world, and as such is wrapped in [`Ghost`].
    ///
    /// # Example
    ///
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    /// let ghost_seq = Seq::<i32>::new();
    /// proof_assert!(seq == Seq::create());
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(*result == Self::empty())]
    #[allow(unreachable_code)]
    pub fn new() -> Ghost<Self> {
        Ghost::conjure()
    }

    /// Returns the number of elements in the sequence, also referred to as its 'length'.
    ///
    /// If you need to get the length in pearlite, consider using [`len`](Self::len).
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     s.push_back(3);
    ///     let len = s.len();
    ///     proof_assert!(len == 3);
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[logic_alias(self.len_logic())]
    pub fn len(&self) -> Int {
        panic!()
    }

    /// Returns `true` if the sequence is empty.
    ///
    /// # Example
    ///
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    /// #[check(ghost)]
    /// #[requires(s.len() == 0)]
    /// pub fn foo(mut s: Seq<i32>) {
    ///     assert!(s.is_empty());
    ///     s.push_back(1i32);
    ///     assert!(!s.is_empty());
    /// }
    /// ghost! {
    ///     foo(Seq::new().into_inner())
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(result == (self.len() == 0))]
    pub fn is_empty(&self) -> bool {
        panic!()
    }

    /// Appends an element to the front of a collection.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_front(1);
    ///     s.push_front(2);
    ///     s.push_front(3);
    ///     proof_assert!(s[0] == 3i32 && s[1] == 2i32 && s[2] == 1i32);
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(^self == self.cons(x))]
    pub fn push_front(&mut self, x: T) {
        let _ = x;
        panic!()
    }

    /// Appends an element to the back of a collection.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     s.push_back(3);
    ///     proof_assert!(s[0] == 1i32 && s[1] == 2i32 && s[2] == 3i32);
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(^self == self.snoc(x))]
    pub fn push_back(&mut self, x: T) {
        let _ = x;
        panic!()
    }

    /// Returns a reference to an element at `index` or `None` if `index` is out of bounds.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(10);
    ///     s.push_back(40);
    ///     s.push_back(30);
    ///     let get1 = s.get(1int);
    ///     let get2 = s.get(3int);
    ///     proof_assert!(get1 == Some(&40i32));
    ///     proof_assert!(get2 == None);
    /// };
    /// ```
    #[check(ghost)]
    #[logic_alias(if 0 <= index && index < self.len() { Some(&self.index_logic(index)) } else { None })]
    pub fn get(&self, index: Int) -> Option<&T> {
        // FIXME: we can't write 0 outside of a `ghost!` block
        if index - index <= index && index < self.len() {
            Some(self.as_refs().extract(index))
        } else {
            None
        }
    }

    /// Returns a mutable reference to an element at `index` or `None` if `index` is out of bounds.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    ///
    /// ghost! {
    ///     s.push_back(0);
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     if let Some(elem) = s.get_mut(1int) {
    ///         *elem = 42;
    ///     }
    ///     proof_assert!(s[0] == 0i32 && s[1] == 42i32 && s[2] == 2i32);
    /// };
    /// ```
    #[check(ghost)]
    #[ensures(match result {
        None => self.get(index) == None && *self == ^self,
        Some(r) => self.get(index) == Some(&*r) && ^r == (^self)[index],
    })]
    #[ensures(forall<i> i != index ==> (*self).get(i) == (^self).get(i))]
    #[ensures((*self).len() == (^self).len())]
    pub fn get_mut(&mut self, index: Int) -> Option<&mut T> {
        // FIXME: we can't write 0 outside of a `ghost!` block
        if index - index <= index && index < self.len() {
            Some(self.as_muts().extract(index))
        } else {
            None
        }
    }

    /// Insert an element in the middle of the sequence.
    ///
    /// The new element is located at index `position`.
    ///
    /// # Example
    ///
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(0);
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     // s = [0, 1, 2]
    ///
    ///     s.insert(0int, 10);
    ///     // s = [10, 0, 1, 2]
    ///     s.insert(2int, 11);
    ///     // s = [10, 0, 11, 1, 2]
    ///     s.insert(5int, 12);
    ///     // s = [10, 0, 11, 1, 2, 12]
    /// };
    /// ```
    #[check(ghost)]
    #[requires(0 <= position && position <= self.len())]
    #[ensures((^self) == self.add_at(position, x))]
    #[variant(position)]
    pub fn insert(&mut self, position: Int, x: T) {
        let after = self.split_off(position);
        self.push_back(x);
        self.extend(after);
    }

    /// Remove an element and discard the rest of the sequence.
    ///
    /// This is sometimes preferable to `remove` because this avoids reasoning about subsequences.
    #[check(ghost)]
    #[requires(0 <= index && index < self.len())]
    #[ensures(result == self[index])]
    #[ensures(forall<i> 0 <= i && i < self.len() && i != index ==> resolve(self[i]))]
    pub fn extract(mut self, index: Int) -> T {
        proof_assert! { forall<i> index < i && i < self.len() ==> self[i] == self[index + 1..][i - index - 1] }
        self.split_off(index).pop_front().unwrap()
    }

    /// Remove an element from a sequence.
    ///
    /// See also the logic function [`Seq::removed`].
    #[check(ghost)]
    #[requires(0 <= index && index < self.len())]
    #[ensures(result == self[index])]
    #[ensures(^self == (*self).removed(index))]
    pub fn remove(&mut self, index: Int) -> T {
        let mut right = self.split_off(index);
        let result = right.pop_front().unwrap();
        self.extend(right);
        result
    }

    /// Append a sequence to another.
    ///
    /// See also the logic function [`Seq::concat`].
    ///
    /// ## Remark
    ///
    /// The second argument is currently restricted to sequences.
    /// Generalizing it to arbitrary `IntoIterator` requires some missing features
    /// to specify that the iterator terminates and that its methods are
    /// callable in ghost code.
    #[check(ghost)]
    #[ensures(^self == (*self).concat(rhs))]
    pub fn extend(&mut self, mut rhs: Self) {
        let _final = snapshot! { self.concat(rhs) };
        #[variant(rhs.len())]
        #[invariant(self.concat(rhs) == *_final)]
        while let Some(x) = rhs.pop_front() {
            self.push_back(x)
        }
    }

    /// Removes the last element from a vector and returns it, or `None` if it is empty.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     s.push_back(3);
    ///     let popped = s.pop_back();
    ///     proof_assert!(popped == Some(3i32));
    ///     proof_assert!(s[0] == 1i32 && s[1] == 2i32);
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(match result {
        None => *self == Seq::empty() && *self == ^self,
        Some(r) => *self == (^self).snoc(r)
    })]
    pub fn pop_back(&mut self) -> Option<T> {
        panic!()
    }

    /// Removes the first element from a vector and returns it, or `None` if it is empty.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     s.push_back(3);
    ///     let popped = s.pop_front();
    ///     proof_assert!(popped == Some(1i32));
    ///     proof_assert!(s[0] == 2i32 && s[1] == 3i32);
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(match result {
        None => *self == Seq::empty() && *self == ^self,
        Some(r) => (*self).len() > 0 && r == (*self)[0] && ^self == (*self).tail()
    })]
    pub fn pop_front(&mut self) -> Option<T> {
        panic!()
    }

    /// Clears the sequence, removing all values.
    ///
    /// # Example
    /// ```rust,creusot
    /// use creusot_std::prelude::*;
    ///
    /// let mut s = Seq::new();
    /// ghost! {
    ///     s.push_back(1);
    ///     s.push_back(2);
    ///     s.push_back(3);
    ///     s.clear();
    ///     proof_assert!(s == Seq::empty());
    /// };
    /// ```
    #[trusted]
    #[check(ghost)]
    #[ensures(^self == Self::empty())]
    pub fn clear(&mut self) {}

    /// Split a sequence in two at the given index.
    #[trusted]
    #[check(ghost)]
    #[requires(0 <= mid && mid <= self.len())]
    #[ensures(^self == self[..mid])]
    #[ensures(result == self[mid..])]
    pub fn split_off(&mut self, mid: Int) -> Self {
        let _ = mid;
        panic!("ghost code")
    }

    /// Borrow every element of a borrowed sequence.
    #[trusted]
    #[check(ghost)]
    #[ensures(*self == result.to_owned_seq())]
    pub fn as_refs(&self) -> Seq<&T> {
        panic!("ghost code")
    }

    /// Mutably borrow every element of a borrowed sequence.
    #[trusted]
    #[check(ghost)]
    #[ensures(result.len() == self.len())]
    #[ensures((^self).len() == self.len())]
    #[ensures(forall<i> 0 <= i && i < self.len() ==> *result[i] == (*self)[i])]
    #[ensures(forall<i> 0 <= i && i < self.len() ==> ^result[i] == (^self)[i])]
    pub fn as_muts(&mut self) -> Seq<&mut T> {
        panic!("ghost code")
    }
}

impl<T> core::ops::Index<Int> for Seq<T> {
    type Output = T;

    #[check(ghost)]
    #[requires(0 <= index && index < self.len())]
    #[ensures(*result == self[index])]
    fn index(&self, index: Int) -> &Self::Output {
        self.get(index).unwrap()
    }
}

impl<T> core::ops::IndexMut<Int> for Seq<T> {
    #[check(ghost)]
    #[requires(0 <= index && index < self.len())]
    #[ensures((*self).len() == (^self).len())]
    #[ensures(*result == (*self)[index] && ^result == (^self)[index])]
    #[ensures(forall<i> 0 <= i && i < self.len() && i != index ==> (*self)[i] == (^self)[i])]
    fn index_mut(&mut self, index: Int) -> &mut Self::Output {
        self.get_mut(index).unwrap()
    }
}

impl<T> core::ops::Index<(Int, Int)> for Seq<T> {
    type Output = (T, T);

    #[trusted]
    #[check(ghost)]
    #[requires(0 <= index.0 && index.0 < self.len() && 0 <= index.1 && index.1 < self.len())]
    #[ensures(result.0 == self[index.0] && result.1 == self[index.1])]
    #[allow(unused_variables)]
    fn index(&self, index: (Int, Int)) -> &Self::Output {
        panic!()
    }
}

impl<T> core::ops::IndexMut<(Int, Int)> for Seq<T> {
    #[trusted]
    #[check(ghost)]
    #[requires(0 <= index.0 && index.0 < self.len() && 0 <= index.1 && index.1 < self.len())]
    #[requires(index.0 != index.1)]
    #[ensures((*result).0 == (*self)[index.0] && (*result).1 == (*self)[index.1]
           && (^result).0 == (^self)[index.0] && (^result).1 == (^self)[index.1])]
    #[ensures(forall<i> i != index.0 && i != index.1 ==> (*self).get(i) == (^self).get(i))]
    #[ensures((*self).len() == (^self).len())]
    #[allow(unused_variables)]
    fn index_mut(&mut self, index: (Int, Int)) -> &mut Self::Output {
        panic!()
    }
}

// Having `Copy` guarantees that the operation is pure, even if we decide to change the definition of `Clone`.
impl<T: Clone + Copy> Clone for Seq<T> {
    #[trusted]
    #[check(ghost)]
    #[ensures(result == *self)]
    fn clone(&self) -> Self {
        *self
    }
}

impl<T: Copy> Copy for Seq<T> {}
impl<T: Plain> Plain for Seq<T> {
    #[requires(inv(*snap))]
    #[ensures(*result == *snap)]
    #[check(ghost)]
    #[allow(unused_variables)]
    fn into_ghost(snap: Snapshot<Self>) -> Ghost<Self> {
        ghost! {
            let mut res = Seq::new().into_inner();
            let len: Snapshot<Int> = snapshot!(snap.len());
            let len = len.into_ghost().into_inner();
            let mut i = 0int;
            #[variant(len - i)]
            #[invariant(i <= len)]
            #[invariant(res.len() == i)]
            #[invariant(forall<j> 0 <= j && j < i ==> res[j] == snap[j])]
            while i < len {
                let elem: Snapshot<T> = snapshot!(snap[i]);
                res.push_back(elem.into_ghost().into_inner());
                i = i + 1int;
            }
            res
        }
    }
}

// =========
// Iterators
// =========

/// Iterator for sequences.
///
/// This provides all three variants of `IntoIter` for `Seq`:
/// `Iter<T>`, `Iter<&T>`, `Iter<&mut T>`.
///
/// This is a different type from `Seq` to enable `IntoIterator for &mut Seq<T>`
/// (if `Seq` were an iterator, that would conflict with `IntoIterator for I where I: Iterator`).
///
/// # Ghost code and variants
///
/// This iterator is only obtainable in ghost code.
///
/// To use it in a `for` loop, a variant must be declared:
/// ```rust,creusot
/// # use creusot_std::prelude::*;
/// # #[requires(true)]
/// fn iter_on_seq<T>(s: Seq<T>) {
///     let len = snapshot!(s.len());
///     #[variant(len - produced.len())]
///     for i in s {
///         // ...
///     }
/// }
/// ```
pub struct Iter<T>(Seq<T>);

impl<T> View for Iter<T> {
    type ViewTy = Seq<T>;
    #[logic]
    fn view(self) -> Self::ViewTy {
        self.0
    }
}

impl<T> Iterator for Iter<T> {
    type Item = T;

    #[check(ghost)]
    #[ensures(match result {
        None => self.completed(),
        Some(v) => (*self).produces(Seq::singleton(v), ^self)
    })]
    fn next(&mut self) -> Option<T> {
        self.0.pop_front()
    }
}

impl<T> IteratorSpec for Iter<T> {
    #[logic(prophetic, inline, open)]
    fn produces(self, visited: Seq<T>, o: Self) -> bool {
        pearlite! { self@ == visited.concat(o@) }
    }

    #[logic(prophetic, inline, open)]
    fn completed(&mut self) -> bool {
        pearlite! { self@ == Seq::empty() }
    }

    #[logic(law)]
    #[ensures(self.produces(Seq::empty(), self))]
    fn produces_refl(self) {}

    #[logic(law)]
    #[requires(a.produces(ab, b))]
    #[requires(b.produces(bc, c))]
    #[ensures(a.produces(ab.concat(bc), c))]
    fn produces_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}
}

impl<T> IntoIterator for Seq<T> {
    type Item = T;
    type IntoIter = Iter<T>;

    #[check(ghost)]
    #[ensures(self == result@)]
    fn into_iter(self) -> Self::IntoIter {
        Iter(self)
    }
}

impl<'a, T> IntoIterator for &'a Seq<T> {
    type Item = &'a T;
    type IntoIter = Iter<&'a T>;

    #[check(ghost)]
    #[ensures(*self == result@.to_owned_seq())]
    fn into_iter(self) -> Self::IntoIter {
        Iter(self.as_refs())
    }
}

impl<'a, T> IntoIterator for &'a mut Seq<T> {
    type Item = &'a mut T;
    type IntoIter = Iter<&'a mut T>;

    #[check(ghost)]
    #[ensures(result@.len() == self.len())]
    #[ensures((^self).len() == self.len())]
    #[ensures(forall<i> 0 <= i && i < self.len() ==> *result@[i] == (*self)[i])]
    #[ensures(forall<i> 0 <= i && i < self.len() ==> ^result@[i] == (^self)[i])]
    fn into_iter(self) -> Self::IntoIter {
        Iter(self.as_muts())
    }
}

impl<T> Resolve for Iter<T> {
    #[logic(open, prophetic, inline)]
    #[creusot::trusted_trivial_if_param_trivial]
    fn resolve(self) -> bool {
        pearlite! { resolve(self@) }
    }

    #[logic(prophetic)]
    #[requires(structural_resolve(self))]
    #[ensures(self.resolve())]
    fn resolve_coherence(self) {}
}
