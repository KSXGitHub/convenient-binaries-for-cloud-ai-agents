//! Resource invariants.
//!
//! Resource invariants allow the use of a shared piece of data to be used in
//! the invariant (see [`Protocol`]), but in return they impose a much more
//! restricted access to the underlying data, as well as the use of [`Tokens`].
//!
//! [Atomic invariants](AtomicInvariant) are used to specify concurrent
//! operations.
//!
//! [Non-atomic invariants](NonAtomicInvariant) are used to specify thread-local
//! operations.
//!
//! Not to be confused with [loop invariants][crate::macros::invariant] or
//! [type invariants][crate::invariant::Invariant].
//!
//! # Example
//!
//! Building a simplified `Cell`, that only asserts its content's type invariant.
//! ```
//! # use creusot_std::{
//! #     cell::PCell,
//! #     ghost::{
//! #         invariant::{NonAtomicInvariant, Protocol, Tokens, declare_namespace},
//! #         perm::Perm,
//! #     },
//! #     logic::Id,
//! #     prelude::*,
//! # };
//! declare_namespace! { PERMCELL }
//!
//! /// A cell that simply asserts its content's type invariant.
//! pub struct CellInv<T: Invariant> {
//!     data: PCell<T>,
//!     permission: Ghost<NonAtomicInvariant<PCellNAInv<T>>>,
//! }
//! impl<T: Invariant> Invariant for CellInv<T> {
//!     #[logic]
//!     fn invariant(self) -> bool {
//!         self.permission.namespace() == PERMCELL() && self.permission.public() == self.data.id()
//!     }
//! }
//!
//! struct PCellNAInv<T>(Perm<PCell<T>>);
//! impl<T: Invariant> Protocol for PCellNAInv<T> {
//!     type Public = Id;
//!
//!     #[logic]
//!     fn public(self) -> Id { self.0.id() }
//!
//!     #[logic]
//!     fn protocol(self) -> bool { true }
//! }
//!
//! impl<T: Invariant> CellInv<T> {
//!     #[requires(tokens.contains(PERMCELL()))]
//!     pub fn write(&self, x: T, tokens: Ghost<Tokens>) {
//!         ghost_let!(perm = &mut self.permission.open(tokens.into_inner()).inner.0);
//!         unsafe { *self.data.borrow_mut(perm) = x }
//!     }
//! }
//! ```
//!
//! # Explicit tokens
//!
//! For now, [`Tokens`] must be explicitely passed to [`open`](NonAtomicInvariant::open).
//! We plan to relax this limitation at some point.

#![allow(unused_variables)]

use crate::{
    ghost::{FnGhost, Plain},
    invariant::{GuardRef, Guarded},
    logic::Set,
    prelude::*,
};
use core::marker::PhantomData;

#[cfg(creusot)]
use crate::ghost::Objective;

/// Declare a new namespace.
///
/// # Example
///
/// ```rust
/// use creusot_std::{ghost::invariant::{declare_namespace, Namespace}, logic::Set, prelude::*};
/// declare_namespace! { A }
///
/// #[requires(ns.contains(A()))]
/// fn foo(ns: Ghost<&mut Set<Namespace>>) { /* ... */ }
/// ```
pub use base_macros::declare_namespace;

/// The type of _namespaces_ of associated with non-atomic invariants.
///
/// Can be declared with the [`declare_namespace`] macro, and then attached to a non-atomic
/// invariant when creating it with [`NonAtomicInvariant::new`].
#[intrinsic("namespace")]
pub struct Namespace(());

impl Clone for Namespace {
    #[check(ghost)]
    #[ensures(result == *self)]
    fn clone(&self) -> Self {
        *self
    }
}
impl Copy for Namespace {}

impl Plain for Namespace {
    #[trusted]
    #[ensures(*result == *snap)]
    #[check(ghost)]
    #[allow(unused_variables)]
    fn into_ghost(snap: Snapshot<Self>) -> Ghost<Self> {
        Ghost::conjure()
    }
}

/// Invariant tokens.
///
/// This is given at the start of the program, and must be passed along to
/// [NonAtomicInvariant::open] to prevent opening invariant reentrantly.
///
/// # Tokens and `open`
///
/// Tokens are used to avoid reentrency in [`open`](NonAtomicInvariant::open).
/// To ensure this, `Tokens` acts as a special kind of mutable borrow : only
/// one may exist at a given point in the program, preventing multiple calls to
/// `open` with the same namespace. This is the reason this type has a lifetime
/// attached to it.
///
/// Note that after the execution of `open`, the token that was used is
/// restored. Because of this, we never need to talk about the 'final' value
/// of this borrow, because it never differs from the current value (in places
/// where we can use it).
///
/// To help passing it into functions, it may be [reborrowed](Self::reborrow),
/// similarly to a normal borrow.
#[opaque]
// `*mut ()` so that Tokens are neither Send nor Sync
pub struct Tokens<'a>(PhantomData<&'a ()>, PhantomData<*mut ()>);

impl<'a> Tokens<'a> {
    /// Get the underlying set of namespaces of this token.
    ///
    /// Also accessible via the [`view`](View::view) (`@`) operator.
    #[logic(opaque)]
    pub fn namespaces(self) -> Set<Namespace> {
        dead
    }

    /// Get the tokens for all the namespaces.
    ///
    /// This is only callable _once_, in `main`.
    #[trusted]
    #[ensures(forall<ns: Namespace> result.contains(ns))]
    #[intrinsic("tokens_new")]
    #[check(ghost)]
    pub fn new() -> Ghost<Self> {
        Ghost::conjure()
    }

    /// Reborrow the token, allowing it to be reused later.
    ///
    /// # Example
    /// ```
    /// # use creusot_std::{ghost::invariant::Tokens, prelude::*};
    /// fn foo(tokens: Ghost<Tokens>) {}
    /// fn bar(tokens: Ghost<Tokens>) {}
    /// fn baz(mut tokens: Ghost<Tokens>) {
    ///     foo(ghost!(tokens.reborrow()));
    ///     bar(tokens);
    /// }
    /// ```
    #[trusted]
    #[ensures(result == *self && ^self == *self)]
    #[check(ghost)]
    pub fn reborrow<'b>(&'b mut self) -> Tokens<'b> {
        Tokens(PhantomData, PhantomData)
    }

    /// Split the tokens in two, so that it can be used to access independent invariants.
    ///
    /// # Example
    ///
    /// ```
    /// # use creusot_std::{ghost::invariant::{declare_namespace, Tokens}, prelude::*};
    /// declare_namespace! { FOO }
    /// declare_namespace! { BAR }
    ///
    /// // the lifetime 'locks' the namespace
    /// #[requires(tokens.contains(FOO()))]
    /// fn foo<'a>(tokens: Ghost<Tokens<'a>>) -> &'a i32 {
    /// # todo!()
    ///     // access some invariant to get the reference
    /// }
    /// #[requires(tokens.contains(BAR()))]
    /// fn bar(tokens: Ghost<Tokens>) {}
    ///
    /// #[requires(tokens.contains(FOO()) && tokens.contains(BAR()))]
    /// fn baz(tokens: Ghost<Tokens>) -> i32 {
    ///      let (ns_foo, ns_bar) = ghost!(tokens.into_inner().split(snapshot!(FOO()))).split();
    ///      let x = foo(ns_foo);
    ///      bar(ns_bar);
    ///      *x
    /// }
    /// ```
    #[trusted]
    #[requires(self.contains(*ns))]
    #[ensures(result.0.contains(*ns))]
    #[ensures(result.1.namespaces() == self.namespaces().remove(*ns))]
    #[check(ghost)]
    pub fn split(self, ns: Snapshot<Namespace>) -> (Tokens<'a>, Tokens<'a>) {
        (Tokens(PhantomData, PhantomData), Tokens(PhantomData, PhantomData))
    }

    #[logic(open)]
    pub fn contains(self, namespace: Namespace) -> bool {
        self.namespaces().contains(namespace)
    }
}

impl View for Tokens<'_> {
    type ViewTy = Set<Namespace>;
    #[logic(open, inline)]
    fn view(self) -> Set<Namespace> {
        self.namespaces()
    }
}

/// A variant of [`Invariant`] for use in `AtomicInvariantSC`s,
/// [`AtomicInvariant`]s and [`NonAtomicInvariant`]s.
///
/// This allows specifying an invariant that depends on some public
/// data (`AtomicInvariantSC::public`, [`AtomicInvariant::public`],
/// [`NonAtomicInvariant::public`]).
pub trait Protocol {
    type Public;

    /// The public data of the invariant, derived from the inner content.
    ///
    /// It is called public, because it is visible simply by holding the
    /// invariant, without needing to open it.
    ///
    /// Because of this, calls to `open` must not modify this value.
    #[logic]
    fn public(self) -> Self::Public;

    /// The protocol for the invariant.
    ///
    /// When opening the invariant ([`AtomicInvariantSC::open`],
    /// [`AtomicInvariant::open`], [`NonAtomicInvariant::open`]), the data in
    /// guaranteed to respect this protocol; then, you must ensure that it is
    /// still verified when the invariant is closed.
    #[logic(prophetic)]
    fn protocol(self) -> bool;
}

/// A shareable invariant for sequentially consistent accesses between threads.
///
/// If you need non-sequentially consistent accesses, use [`AtomicInvariant`].
///
/// If you do not need to share the invariant across threads, see
/// [`NonAtomicInvariant`].
#[cfg(feature = "sc-drf")]
#[opaque]
pub struct AtomicInvariantSC<T>(PhantomData<*mut T>);

#[cfg(feature = "sc-drf")]
#[trusted]
unsafe impl<T: Send> Sync for AtomicInvariantSC<T> {}

#[cfg(feature = "sc-drf")]
#[trusted]
unsafe impl<T: Send> Send for AtomicInvariantSC<T> {}

#[cfg(feature = "sc-drf")]
impl<T: Protocol> AtomicInvariantSC<T> {
    /// Construct a `AtomicInvariantSC`, aka a sequentially consistent atomic invariant.
    ///
    /// # Parameters
    ///
    /// - `value`: the actual data contained in the invariant. Use [`Self::open`] to
    /// access it. Also called the 'private' part of the invariant.
    /// - `namespace`: the namespace of the invariant.
    ///   This is required to avoid [open](Self::open)ing the same invariant twice.
    #[trusted]
    #[requires(value.protocol())]
    #[ensures(result.public() == value.public())]
    #[ensures(result.namespace() == *namespace)]
    #[check(ghost)]
    pub fn new(value: Ghost<T>, namespace: Snapshot<Namespace>) -> Ghost<Self> {
        Ghost::conjure()
    }

    /// Get the namespace associated with this invariant.
    #[logic(opaque)]
    pub fn namespace(self) -> Namespace {
        dead
    }

    /// Get the 'public' part of this invariant.
    #[logic(opaque)]
    pub fn public(self) -> T::Public {
        dead
    }

    /// Gives the actual invariant held by the `AtomicInvariantSC`.
    #[trusted]
    #[ensures(result.public() == self.public() && result.protocol())]
    #[check(ghost)]
    pub fn into_inner(self) -> T {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside.
    ///
    /// This will call the closure `f` with the inner data. You must restore the
    /// contained [`Protocol`] before returning from the closure.
    ///
    /// NOTE: This function can only be called from ghost code, because atomic
    /// invariants are always wrapped in `Ghost`. This guarantees atomicity.
    #[trusted]
    #[requires(tokens.contains(self.namespace()))]
    #[requires(forall<t: &mut T> t.public() == self.public() && t.protocol() && inv(t) ==>
        f.precondition((t,)) &&
        // f must restore the invariant
        (forall<res: A> f.postcondition_once((t,), res) ==> (^t).public() == self.public() && (^t).protocol()))]
    #[ensures(exists<t: &mut T> t.public() == self.public() && t.protocol() && inv(t) &&
        f.postcondition_once((t,), result))]
    #[check(ghost)]
    pub fn open<A>(&self, tokens: Tokens, f: impl FnGhost + for<'a> FnOnce(&'a mut T) -> A) -> A {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside. The
    /// [protocol](Protocol) must be restored by the end of the returned
    /// borrow's lifetime.
    ///
    /// This requires a mutable borrow on the invariant, but in exchange, you
    /// are allowed to change the public part of the invariant.
    ///
    /// See [`Self::open`] for a version that only need a shared borrow,
    /// but cannot change the public part.
    #[trusted]
    #[check(ghost)]
    #[ensures(result.inner.public() == self.public())]
    #[ensures((^result.inner).public() == (^self).public())]
    #[ensures((^self).namespace() == (*self).namespace())]
    pub fn open_mut(&mut self) -> Guarded<&mut T, OpenMutGuard> {
        unreachable!("ghost code only")
    }
}

/// A shareable invariant for atomic accesses between threads.
///
/// If you need _sequentially consistent_ accesses, use [`AtomicInvariant`].
///
/// If you do not need to share the invariant across threads, see
/// [`NonAtomicInvariant`].
#[opaque]
pub struct AtomicInvariant<T>(PhantomData<*mut T>);

// TODO: Find a real hack to achieve this.
#[cfg(creusot)]
#[trusted]
unsafe impl<T: Send + Objective> Sync for AtomicInvariant<T> {}
#[cfg(not(creusot))]
unsafe impl<T: Send> Sync for AtomicInvariant<T> {}

#[trusted]
unsafe impl<T: Send> Send for AtomicInvariant<T> {}

impl<T: Protocol> AtomicInvariant<T> {
    /// Construct a `AtomicInvariant`
    ///
    /// # Parameters
    /// - `value`: the actual data contained in the invariant. Use [`Self::open`] to
    /// access it. Also called the 'private' part of the invariant.
    /// - `namespace`: the namespace of the invariant.
    ///   This is required to avoid [open](Self::open)ing the same invariant twice.
    #[trusted]
    #[requires(value.protocol())]
    #[ensures(result.public() == value.public())]
    #[ensures(result.namespace() == *namespace)]
    #[check(ghost)]
    pub fn new(value: Ghost<T>, namespace: Snapshot<Namespace>) -> Ghost<Self> {
        Ghost::conjure()
    }

    /// Get the namespace associated with this invariant.
    #[logic(opaque)]
    pub fn namespace(self) -> Namespace {
        dead
    }

    /// Get the 'public' part of this invariant.
    #[logic(opaque)]
    pub fn public(self) -> T::Public {
        dead
    }

    /// Gives the actual invariant held by the `AtomicInvariant`.
    #[trusted]
    #[ensures(result.public() == self.public() && result.protocol())]
    #[check(ghost)]
    pub fn into_inner(self) -> T {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside.
    ///
    /// This will call the closure `f` with the inner data. You must restore the
    /// contained [`Protocol`] before returning from the closure.
    ///
    /// NOTE: This function can only be called from ghost code, because atomic
    /// invariants are always wrapped in `Ghost`. This guarantees atomicity.
    #[trusted]
    #[requires(tokens.contains(self.namespace()))]
    #[requires(forall<t: &mut T> t.public() == self.public() && t.protocol() && inv(t) ==>
        f.precondition((t,)) &&
        // f must restore the invariant
        (forall<res: A> f.postcondition_once((t,), res) ==> (^t).public() == self.public() && (^t).protocol()))]
    #[ensures(exists<t: &mut T> t.public() == self.public() && t.protocol() && inv(t) &&
        f.postcondition_once((t,), result))]
    #[check(ghost)]
    pub fn open<A>(&self, tokens: Tokens, f: impl FnGhost + for<'a> FnOnce(&'a mut T) -> A) -> A {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside. The
    /// [protocol](Protocol) must be restored by the end of the returned
    /// borrow's lifetime.
    ///
    /// This requires a mutable borrow on the invariant, but in exchange, you
    /// are allowed to change the public part of the invariant.
    ///
    /// See [`Self::open`] for a version that only need a shared borrow,
    /// but cannot change the public part.
    #[trusted]
    #[check(ghost)]
    #[ensures(result.inner.public() == self.public())]
    #[ensures((^result.inner).public() == (^self).public())]
    #[ensures((^self).namespace() == (*self).namespace())]
    pub fn open_mut(&mut self) -> Guarded<&mut T, OpenMutGuard> {
        unreachable!("ghost code only")
    }
}

/// A ghost structure, that holds a piece of data (`T`) together with an
/// [protocol](Protocol).
///
/// # Note
///
/// `NonAtomicInvariant` is not [`Sync`], and is invariant in the underlying data.
/// - It is not `Sync` precisely because it is non-atomic, so access to the data is unsynchronized.
/// - It is invariant because it gives access to a mutable borrow of this data.
///
/// If you need to share an invariant across threads, consider
/// `AtomicInvariantSC` or [`AtomicInvariant`].
#[opaque]
pub struct NonAtomicInvariant<T: Protocol>(PhantomData<*mut T>);

#[trusted]
unsafe impl<T: Protocol> Send for NonAtomicInvariant<T> {}

/// Guard for [`NonAtomicInvariant::open`].
///
/// This contains the public value, that must be unchanged for the
/// borrow. Additionally, the guard asserts that the borrow satisfies its
/// [protocol](Protocol).
pub struct OpenGuard<T: Protocol>(pub T::Public);

impl<T: Protocol> GuardRef<T> for OpenGuard<T> {
    #[logic(open, prophetic, inline)]
    fn guards_ref(self, b: T) -> bool {
        b.public() == self.0 && b.protocol()
    }
}

/// Guard for [`NonAtomicInvariant::open_mut`].
pub struct OpenMutGuard;
impl<T: Protocol> GuardRef<T> for OpenMutGuard {
    #[logic(open, prophetic, inline)]
    fn guards_ref(self, x: T) -> bool {
        x.protocol()
    }
}

impl<T: Protocol> NonAtomicInvariant<T> {
    /// Construct a `NonAtomicInvariant`
    ///
    /// # Parameters
    ///
    /// - `value`: the actual data contained in the invariant. Use [`Self::open`] to
    /// access it. Also called the 'private' part of the invariant.
    /// - `namespace`: the namespace of the invariant.
    ///   This is required to avoid [open](Self::open)ing the same invariant twice.
    #[trusted]
    #[requires(value.protocol())]
    #[ensures(result.public() == value.public())]
    #[ensures(result.namespace() == *namespace)]
    #[check(ghost)]
    pub fn new(value: Ghost<T>, namespace: Snapshot<Namespace>) -> Ghost<Self> {
        Ghost::conjure()
    }

    /// Gives the actual invariant held by the `NonAtomicInvariant`.
    #[trusted]
    #[ensures(result.public() == self.public() && result.protocol())]
    #[check(ghost)]
    pub fn into_inner(self) -> T {
        panic!("Should not be called outside ghost code")
    }

    /// Get the namespace associated with this invariant.
    #[logic(opaque)]
    pub fn namespace(self) -> Namespace {
        dead
    }

    /// Get the 'public' part of this invariant.
    #[logic(opaque)]
    pub fn public(self) -> T::Public {
        dead
    }

    /// Open the invariant to get the data stored inside.
    ///
    /// The returned borrow satisfies the [protocol](Protocol) on `T`.
    /// This protocol must be re-established before this borrow ends, with the same [public value](Protocol::public).
    ///
    /// # Notes on `ghost_let`
    ///
    /// The [`Guarded`] type can assert its type invariant at inconvenient times.
    /// To work around this, it is often desirable to use a [`ghost_let`] to extract the inner borrow, and be able to freely break the protocol during its lifetime:
    /// ```
    /// use creusot_std::{
    ///     ghost::invariant::{NonAtomicInvariant, Protocol, Tokens, declare_namespace},
    ///     prelude::*,
    /// };
    /// struct Gt0(i32);
    /// impl Protocol for Gt0 {
    ///     type Public = ();
    ///     #[logic] fn public(self) {}
    ///     #[logic] fn protocol(self) -> bool { self.0 > 0i32 }
    /// }
    ///
    /// declare_namespace! { NS }
    ///
    /// #[requires(tokens.contains(NS()))]
    /// fn foo(tokens: Ghost<Tokens>) {
    ///     let inv = NonAtomicInvariant::new(ghost!(Gt0(1i32)), snapshot!(NS()));
    ///     // ...
    ///     ghost_let!(mut gt = &mut *inv.open(tokens.into_inner()).inner);
    ///
    ///     ghost! { gt.0 = -1 };
    ///     // ... maybe do some non-ghost operations here ...
    ///     ghost! { gt.0 = 2 };
    /// }
    /// ```
    ///
    /// If we were using the `guard` variable directly, the type invariant (and
    /// thus the protocol) would be asserted at the end of each `ghost! { gt.0 =
    /// ... }` block, and the first would fail.
    #[trusted]
    #[requires(tokens.contains(self.namespace()))]
    #[ensures(result.guard().0 == self.public())]
    #[check(ghost)]
    pub fn open<'a>(&'a self, tokens: Tokens<'a>) -> Guarded<&'a mut T, OpenGuard<T>> {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside, immutably.
    /// This allows reentrant access to the invariant.
    #[trusted]
    #[requires(tokens.contains(self.namespace()))]
    #[ensures(result.public() == self.public() && result.protocol())]
    #[check(ghost)]
    pub fn open_const<'a>(&'a self, tokens: &'a Tokens) -> &'a T {
        panic!("Should not be called outside ghost code")
    }

    /// Open the invariant to get the data stored inside. The
    /// [protocol](Protocol) must be restored by the end of the returned
    /// borrow's lifetime.
    ///
    /// This requires a mutable borrow on the invariant, but in exchange, you
    /// are allowed to change the public part of the invariant.
    ///
    /// See [`Self::open`] for a version that only need a shared borrow,
    /// but cannot change the public part.
    #[trusted]
    #[check(ghost)]
    #[ensures(result.inner.public() == self.public())]
    #[ensures((^result.inner).public() == (^self).public())]
    #[ensures((^self).namespace() == (*self).namespace())]
    pub fn open_mut(&mut self) -> Guarded<&mut T, OpenMutGuard> {
        unreachable!("ghost code only")
    }
}
